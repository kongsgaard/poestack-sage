"use strict";var t={},e={},o={},l={},r={action:t,title:e,label:o,body:l};exports.action=t,exports.body=l,exports.default=r,exports.label=o,exports.title=e;
